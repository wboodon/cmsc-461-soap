#!/usr/bin/python
# -*- coding: utf-8 -*-

import csv
import sqlite3 as lite
import sys
from os import system, name

menu_options = """
Menu
----
0) Load data from csv files
1) Erase tables
2) Insert record into table
3) Delete record from table
4) Custom SQL query
5) Quit
"""

table_options = """
Tables
------
0) gsaOffice
1) customerAgencies
2) managesAgreements
3) rentalAgreement
4) has
5) go back
"""

def load_csv(cur):
    try:
        # Read gsaOffice.csv into gsaOffice table.
        with open('gsaOffice.csv', newline='\n') as csvfile:
            reader = csv.reader(csvfile, delimiter=',')
            for row in reader:
                cur.execute("insert into gsaOffice values(?, ?, ?);", (row[0], row[1], row[2]))
        
        print("Read gsaOffice.csv.")
        
        # Read customerAgencies.csv into customerAgencies table.
        with open('customerAgencies.csv', newline='\n') as csvfile:
            reader = csv.reader(csvfile, delimiter=',')
            for row in reader:
                cur.execute("insert into customerAgencies values(?, ?, ?, ?, ?);", (row[0], row[1], row[2], row[3], row[4]))
        
        print("Read customerAgencies.csv.")
        
        # Read has.csv into has table.
        with open('has.csv', newline='\n') as csvfile:
            reader = csv.reader(csvfile, delimiter=',')
            for row in reader:
                cur.execute("insert into has values(?, ?);", (row[0], row[1]))
        
        print("Read has.csv.")
        
        # Read managesAgreements.csv into managesAgreements table.
        with open('managesAgreements.csv', newline='\n') as csvfile:
            reader = csv.reader(csvfile, delimiter=',')
            for row in reader:
                cur.execute("insert into managesAgreements values(?, ?);", (row[0], row[1]))
        
        print("Read managesAgreements.csv.")
        
        # Read rentalAgreement.csv into rentalAgreement table.
        with open('rentalAgreement.csv', newline='\n') as csvfile:
            reader = csv.reader(csvfile, delimiter=',')
            for row in reader:
                cur.execute("insert into rentalAgreement values(?, ?, ?);", (row[0], row[1], row[2]))
        
        print("Read rentalAgreement.csv.")
        print("All files read successfully!")
    
    except:
        print("There was an error loading the csv data into the tables")
    
    print("")

def erase_tables(cur):
    print("Select a table to erase.")
    choice = int(input(table_options))

    tablename = ""
    if choice == 0:
        tablename = "gsaOffice"
    elif choice == 1:
        tablename = "customerAgencies"
    elif choice == 2:
        tablename = "managesAgreements"
    elif choice == 3:
        tablename = "rentalAgreement"
    elif choice == 4:
        tablename = "has"
    elif choice < 0 or choice >= 5:
        print("Invalid input")
    
    try:
        if tablename != "":
            cur.execute("drop table " + tablename + ";")
            print("Table erased.")
    except:
        print("There was an error erasing that table.")
    
    print("")
    

def insert_record(cur):
    print("Select a table to insert into: ")
    choice = int(input(table_options))

    tablename = ""
    if choice == 0:
        tablename = "gsaOffice"
    elif choice == 1:
        tablename = "customerAgencies"
    elif choice == 2:
        tablename = "managesAgreements"
    elif choice == 3:
        tablename = "rentalAgreement"
    elif choice == 4:
        tablename = "has"
    elif choice < 0 or choice >= 5:
        print("Invalid input")

    try:
        if tablename != "":
            cur.execute("select * from " + tablename + ";")
            data = cur.fetchall()
            print("Your table: ")
            for rec in data:
                for field in rec:
                    print(field,"\t",end='')
                print()
            print("Now, enter your insert statement.")
            custom_query(cur)
    except:
        print("There was an error printing that table.")


def delete_record(cur):
    print("Select a table to delete from: ")
    choice = int(input(table_options))

    tablename = ""
    if choice == 0:
        tablename = "gsaOffice"
    elif choice == 1:
        tablename = "customerAgencies"
    elif choice == 2:
        tablename = "managesAgreements"
    elif choice == 3:
        tablename = "rentalAgreement"
    elif choice == 4:
        tablename = "has"
    elif choice < 0 or choice >= 5:
        print("Invalid input")

    try:
        if tablename != "":
            cur.execute("select * from " + tablename + ";")
            data = cur.fetchall()
            print("Your table: ")
            for rec in data:
                for field in rec:
                    print(field,"\t",end='')
                print()
            print("Now, enter your delete statement.")
            custom_query(cur)
    except:
        print("There was an error printing that table.")
    

def custom_query(cur):
    myStmt = input('Enter SQL Statement :')
    if myStmt != "quit":
        cur.execute(myStmt)
        data = cur.fetchall()
        print("The results are: ")
        for rec in data:
            for field in rec:
                print(field,"\t",end='')
            print()
    print()
    myWait = input('Press enter to continue :') 



def main_menu(cur):
    choice = -1
    while choice != 5:
        choice = int(input(menu_options))
        system('cls')
        if choice == 0:
            load_csv(cur)
        elif choice == 1:
            erase_tables(cur)
        elif choice == 2:
            insert_record(cur)
        elif choice == 3:
            delete_record(cur)
        elif choice == 4:
            custom_query(cur)
        elif choice != 5:
            print("Invalid menu option. Please try again.")

    print("Good bye!")


def main():
    con = None
    try:
        con = lite.connect("soap.db")
        cur = con.cursor()
        main_menu(cur)
        con.commit()
        con.close()

    except lite.Error as e:
        print("Error %s:" % e.args[0])
        sys.exit(1)


if __name__ == "__main__":
    main()